import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:pet_care/screens/pages/dashboard/editProfile/edit_profile_screen.dart';

class PetCareDashboard extends StatelessWidget {

  void _navigateToEditProfile(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => EditProfileScreen()),
    );
  }

  void _navigateToMedicalRecords(BuildContext context) {
    // Add code to navigate to Medical Records screen
    Navigator.push(
    context,
    MaterialPageRoute(
      builder: (context) => Scaffold(
        appBar: AppBar(
          title: Text('Medical Records'),
        ),
        body: Center(
          child: Text('This is the medical records screen'),
        ),
        ),
      ),
    );
  }

  void _navigateToSettings(BuildContext context) {
    // Add code to navigate to Settings screen
    Navigator.push(
    context,
    MaterialPageRoute(
      builder: (context) => Scaffold(
        appBar: AppBar(
          title: Text('Settings'),
        ),
        body: Center(
          child: Text('This is the Setting screen'),
        ),
        ),
      ),
    );
  }

  void _navigateToFeedback(BuildContext context) {
    // Add code to navigate to Feedback screen
    Navigator.push(
    context,
    MaterialPageRoute(
      builder: (context) => Scaffold(
        appBar: AppBar(
          title: Text('Feedback Records'),
        ),
        body: Center(
          child: Text('This is the feedback screen'),
        ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: Container(
          color: Colors.white54,
          child: Column(
            children: [
              const SizedBox(
                height: 15,
              ),
              MouseRegion(
              cursor: SystemMouseCursors.click,
              child: GestureDetector(
                onTap: () {
                  Navigator.pop(context);
                },
                child: const ListTile(
                  leading: Icon(Icons.arrow_back),
                  trailing: Icon(Icons.menu),
                ),
              ),
            ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  Text(
                    "Profile Dashboard",
                    style: TextStyle(fontWeight: FontWeight.w900, fontSize: 26),
                  )
                ],
              ),
              Container(
                child: Expanded(
                  child: ListView(
                    children: [
                      GestureDetector(
                        onTap: () => _navigateToEditProfile(context),
                        child: Card(
                          margin:
                              const EdgeInsets.only(left: 35, right: 35, bottom: 10),
                          color: Colors.white70,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30)),
                          child: const ListTile(
                            leading: Icon(
                              Icons.privacy_tip_sharp,
                              color: Colors.black54,
                            ),
                            title: Text(
                              'Profile',
                              style: TextStyle(
                                  fontSize: 18, fontWeight: FontWeight.bold),
                            ),
                            trailing: Icon(
                              Icons.arrow_forward_ios_outlined,
                              color: Colors.black54,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      GestureDetector(
                        onTap: () => _navigateToMedicalRecords(context),
                        child: Card(
                          color: Colors.white70,
                          margin:
                              const EdgeInsets.only(left: 35, right: 35, bottom: 10),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30)),
                          child: const ListTile(
                            leading: Icon(
                              Icons.history,
                              color: Colors.black54,
                            ),
                            title: Text(
                              'Medical Records',
                              style: TextStyle(
                                  fontSize: 18, fontWeight: FontWeight.bold),
                            ),
                            trailing: Icon(
                              Icons.arrow_forward_ios_outlined,
                              color: Colors.black54,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      GestureDetector(
                        onTap: () => _navigateToSettings(context),
                        child: Card(
                          color: Colors.white70,
                          margin: const EdgeInsets.only(left: 35, right: 35, bottom: 10),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                          child: const ListTile(
                            leading: Icon(Icons.help_outline, color: Colors.black54),
                            title: Text(
                              'Settings',
                              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                            ),
                            trailing:
                                Icon(Icons.arrow_forward_ios_outlined, color: Colors.black54),
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      GestureDetector(
                        onTap: () => _navigateToFeedback(context),
                        child: Card(
                          color: Colors.white70,
                          margin: const EdgeInsets.only(left: 35, right: 35, bottom: 10),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                          child: const ListTile(
                            leading: Icon(Icons.privacy_tip_sharp, color: Colors.black54),
                            title: Text(
                              'Feedback',
                              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                            ),
                            trailing:
                                Icon(Icons.arrow_forward_ios_outlined, color: Colors.black54),
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                    ],
                  )),
                )
              ],
            ),
          ),




        ));
  }
}
