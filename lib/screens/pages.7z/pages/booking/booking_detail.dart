import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class BookingDetailScreen extends StatelessWidget {
  final String bookingId;

  const BookingDetailScreen({required this.bookingId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Booking Details'),
      ),
      body: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        stream: FirebaseFirestore.instance.collection('bookings').doc(bookingId).snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return CircularProgressIndicator();
          }

          final bookingData = snapshot.data!.data()!;
          return Padding(
            padding: const EdgeInsets.all(16.0),
            child: Table(
              columnWidths: {0: FixedColumnWidth(120.0)},
              children: [
                _buildTableRow('Pet Name:', bookingData['petName']),
                _buildTableRow('Owner Name:', bookingData['ownerName']),
                _buildTableRow('Date:', bookingData['date']),
                _buildTableRow('Time:', bookingData['time']),
                _buildTableRow('Duration:', bookingData['duration']),
                _buildTableRow('Address:', bookingData['address']),
                _buildTableRow('Notes:', bookingData['notes']),
                _buildTableRow('Status:', bookingData['status']),
                _buildTableRow('Appointment Type:', bookingData['appointmentType']),
                _buildTableRow('Contact Info:', bookingData['contactInfo']),
                _buildTableRow('Contact Info:', bookingData['reasonForVisit']),
              ],
            ),
          );
        },
      ),
    );
  }

  TableRow _buildTableRow(String label, String? value) {
    return TableRow(
      children: [
        TableCell(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(
              label,
              style: TextStyle(
                fontSize: 16.0,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
        TableCell(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(
              value ?? 'N/A',
              style: TextStyle(fontSize: 16.0),
            ),
          ),
        ),
      ],
    );
  }
}
